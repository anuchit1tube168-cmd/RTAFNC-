create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  employee_code text unique not null,
  employee_name text not null,
  department text,
  role text not null default 'employee',
  line_user_id text unique,
  line_display_name text,
  line_picture_url text,
  line_friend_status text not null default 'unknown',
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  message_type text not null default 'announcement',
  target_type text not null,
  target_value text,
  liff_url text,
  created_by uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.notification_queue (
  id uuid primary key default gen_random_uuid(),
  announcement_id uuid references public.announcements(id) on delete cascade,
  profile_id uuid references public.profiles(id) on delete cascade,
  line_user_id text not null,
  payload jsonb not null,
  status text not null default 'pending',
  retry_count integer not null default 0,
  scheduled_at timestamptz not null default now(),
  sent_at timestamptz,
  error_message text,
  created_at timestamptz not null default now()
);

create index if not exists idx_profiles_line_user_id on public.profiles(line_user_id);
create index if not exists idx_profiles_department on public.profiles(department);
create index if not exists idx_notification_queue_status_schedule on public.notification_queue(status, scheduled_at);

alter table public.profiles enable row level security;
alter table public.announcements enable row level security;
alter table public.notification_queue enable row level security;

-- ปรับ policy ตามระบบ Auth จริงก่อนใช้งาน Production
create policy "authenticated read profiles" on public.profiles for select to authenticated using (true);
create policy "authenticated read announcements" on public.announcements for select to authenticated using (true);

-- ตัวอย่าง function สำหรับผูก LINE User ID กับรหัสพนักงานครั้งแรก
create or replace function public.link_line_account(
  p_employee_code text,
  p_line_user_id text,
  p_display_name text,
  p_picture_url text
) returns public.profiles
language plpgsql
security definer
set search_path = public
as $$
declare
  result public.profiles;
begin
  update public.profiles
  set line_user_id = p_line_user_id,
      line_display_name = p_display_name,
      line_picture_url = p_picture_url,
      line_friend_status = 'friend',
      updated_at = now()
  where employee_code = p_employee_code and active = true
  returning * into result;

  if result.id is null then
    raise exception 'employee_not_found_or_inactive';
  end if;

  return result;
end;
$$;
