-- RTAFNC LIFF Phase 1.2
-- Run after rtafnc_phase1.sql

create table if not exists public.good_deed_categories (
  code text primary key,
  sort_order smallint unique not null,
  name_th text not null,
  description_th text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

insert into public.good_deed_categories (code, sort_order, name_th, description_th)
values
  ('GD01',1,'บริจาคโลหิต / เกล็ดเลือด / พลาสมา','กิจกรรมบริจาคโลหิตและส่วนประกอบโลหิต'),
  ('GD02',2,'โครงการภายนอกที่ออกคำสั่งจาก วพอ.','ปฏิบัติงานภายนอกตามคำสั่งของวิทยาลัย'),
  ('GD03',3,'ช่วยเหลืองานภายใน วพอ.','สนับสนุนงานและกิจกรรมภายในวิทยาลัย'),
  ('GD04',4,'เข้ารับการอบรมต่าง ๆ ที่ วพอ. จัด','อบรมหรือพัฒนาความรู้ตามที่วิทยาลัยจัด'),
  ('GD05',5,'ช่วยงานหน่วยงาน ชุมชน หรือมูลนิธิ','กิจกรรมช่วยเหลือสังคมและหน่วยงานภายนอก'),
  ('GD06',6,'ทำนุบำรุงศาสนสถาน','กิจกรรมดูแลหรือพัฒนาศาสนสถาน'),
  ('GD07',7,'งานฟรีทั่วไป','งานอาสาทั่วไปที่ไม่รับค่าตอบแทน'),
  ('GD08',8,'กิจกรรมแสดงความจงรักภักดีต่อสถาบันพระมหากษัตริย์','กิจกรรมถวายความเคารพและแสดงความจงรักภักดี')
on conflict (code) do update set
  sort_order = excluded.sort_order,
  name_th = excluded.name_th,
  description_th = excluded.description_th,
  active = true;

create table if not exists public.good_deed_records (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  category_code text not null references public.good_deed_categories(code),
  activity_date date not null,
  activity_title text not null,
  activity_location text,
  details text not null,
  verifier_name text,
  requested_hours numeric(6,2) not null check (requested_hours > 0 and requested_hours <= 24),
  approved_hours numeric(6,2) check (approved_hours >= 0 and approved_hours <= 24),
  academic_year smallint not null,
  semester smallint check (semester in (1,2,3)),
  status text not null default 'pending' check (status in ('draft','pending','approved','returned','rejected')),
  rejection_reason text,
  submitted_at timestamptz not null default now(),
  reviewed_by uuid,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.good_deed_attachments (
  id uuid primary key default gen_random_uuid(),
  record_id uuid not null references public.good_deed_records(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  storage_path text not null,
  file_name text not null,
  mime_type text not null,
  file_size bigint not null check (file_size >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.hospital_visits (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.students(id) on delete cascade,
  visit_date date not null,
  hospital_name text not null,
  symptoms text not null,
  diagnosis text,
  treatment_note text,
  medication_note text,
  medical_leave_days numeric(4,1) not null default 0 check (medical_leave_days >= 0),
  follow_up_date date,
  status text not null default 'recorded' check (status in ('recorded','follow_up','resolved','cancelled')),
  academic_year smallint not null,
  semester smallint check (semester in (1,2,3)),
  created_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.hospital_attachments (
  id uuid primary key default gen_random_uuid(),
  visit_id uuid not null references public.hospital_visits(id) on delete cascade,
  student_id uuid not null references public.students(id) on delete cascade,
  document_type text not null default 'medical_document' check (document_type in ('medical_certificate','prescription','receipt','appointment','medical_document')),
  storage_path text not null,
  file_name text not null,
  mime_type text not null,
  file_size bigint not null check (file_size >= 0),
  created_at timestamptz not null default now()
);

create index if not exists idx_good_deed_records_student_date on public.good_deed_records(student_id, activity_date desc);
create index if not exists idx_good_deed_records_status on public.good_deed_records(status, submitted_at desc);
create index if not exists idx_hospital_visits_student_date on public.hospital_visits(student_id, visit_date desc);
create index if not exists idx_hospital_visits_status on public.hospital_visits(status, follow_up_date);

alter table public.good_deed_categories enable row level security;
alter table public.good_deed_records enable row level security;
alter table public.good_deed_attachments enable row level security;
alter table public.hospital_visits enable row level security;
alter table public.hospital_attachments enable row level security;

-- Public may read only the category master list.
drop policy if exists "read active good deed categories" on public.good_deed_categories;
create policy "read active good deed categories"
on public.good_deed_categories
for select
to anon, authenticated
using (active = true);

grant select on public.good_deed_categories to anon, authenticated;

-- No anonymous access to personal good-deed or hospital data.
revoke all on public.good_deed_records from anon;
revoke all on public.good_deed_attachments from anon;
revoke all on public.hospital_visits from anon;
revoke all on public.hospital_attachments from anon;

-- IMPORTANT
-- Do not add student-data policies until LINE ID token verification and member sessions exist.
-- Hospital data must use stricter role policies than good-deed data.
-- Keep hospital files in a separate PRIVATE bucket from good-deed evidence.
