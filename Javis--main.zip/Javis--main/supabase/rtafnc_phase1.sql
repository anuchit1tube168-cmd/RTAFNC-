-- RTAFNC LIFF Phase 1
-- Run in Supabase SQL Editor on a NEW project.
-- This phase exposes only a non-sensitive health check and published general announcements.

create extension if not exists pgcrypto;

create table if not exists public.app_settings (
  id integer primary key default 1 check (id = 1),
  app_name text not null default 'RTAFNC Member',
  version text not null default 'phase-1.0.0',
  maintenance_mode boolean not null default false,
  updated_at timestamptz not null default now()
);

insert into public.app_settings (id, app_name, version, maintenance_mode)
values (1, 'RTAFNC Member', 'phase-1.0.0', false)
on conflict (id) do update set
  app_name = excluded.app_name,
  version = excluded.version,
  updated_at = now();

create table if not exists public.students (
  id uuid primary key default gen_random_uuid(),
  student_code text unique not null,
  title text,
  first_name text not null,
  last_name text not null,
  cohort smallint,
  current_year smallint check (current_year between 1 and 4),
  academic_year smallint,
  date_of_birth date,
  profile_path text,
  active_status text not null default 'active' check (active_status in ('active','graduated','suspended','inactive')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.line_accounts (
  id uuid primary key default gen_random_uuid(),
  student_id uuid unique not null references public.students(id) on delete cascade,
  line_user_id text unique not null,
  line_display_name text,
  line_picture_url text,
  verified_at timestamptz,
  last_login_at timestamptz,
  friend_status text not null default 'unknown' check (friend_status in ('unknown','friend','blocked')),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  category text not null default 'general',
  target_type text not null default 'all' check (target_type in ('all','cohort','study_year','student')),
  target_value text,
  cover_path text,
  attachment_path text,
  is_published boolean not null default false,
  published_at timestamptz not null default now(),
  expires_at timestamptz,
  created_by uuid,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_students_student_code on public.students(student_code);
create index if not exists idx_line_accounts_line_user_id on public.line_accounts(line_user_id);
create index if not exists idx_announcements_public_feed on public.announcements(is_published, target_type, published_at desc);

alter table public.app_settings enable row level security;
alter table public.students enable row level security;
alter table public.line_accounts enable row level security;
alter table public.announcements enable row level security;

-- No direct anonymous access to student identity or LINE-account tables.
revoke all on public.students from anon;
revoke all on public.line_accounts from anon;

-- Phase 1 public feed: only general announcements intended for everyone.
drop policy if exists "public reads published general announcements" on public.announcements;
create policy "public reads published general announcements"
on public.announcements
for select
to anon, authenticated
using (
  is_published = true
  and target_type = 'all'
  and published_at <= now()
  and (expires_at is null or expires_at > now())
);

-- A safe connection test. It returns no student or secret data.
create or replace function public.system_health()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'ok', true,
    'app_name', app_name,
    'version', version,
    'maintenance_mode', maintenance_mode,
    'server_time', now()
  )
  from public.app_settings
  where id = 1;
$$;

revoke all on function public.system_health() from public;
grant execute on function public.system_health() to anon, authenticated;

grant usage on schema public to anon, authenticated;
grant select on public.announcements to anon, authenticated;

-- Demo public announcements. Remove or edit after testing.
insert into public.announcements
  (title, body, category, target_type, is_published, published_at)
values
  ('เปิดรับสมัครบริจาคโลหิต', 'ลงทะเบียนผ่านหน้า LIFF และติดตามสถานะได้ในระบบ', 'blood', 'all', true, now()),
  ('กิจกรรมจิตอาสาประจำเดือน', 'นักเรียนสามารถบันทึกกิจกรรมและแนบหลักฐานได้จากเมนูทุกความดี', 'good_deed', 'all', true, now())
on conflict do nothing;

-- IMPORTANT FOR PHASE 2
-- 1) Do not create anonymous policies for students or line_accounts.
-- 2) Verify LINE ID tokens in a Supabase Edge Function before issuing a member session.
-- 3) Add private Storage buckets and policies before uploading real images/PDFs.
-- 4) Add audit logs and role-based policies before importing health data.
