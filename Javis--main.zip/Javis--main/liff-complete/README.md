# AGIS Member LIFF Complete

หน้า LIFF Member Portal สำหรับเปิดจาก LINE Official Account Rich Menu

## เปิดตัวอย่าง

`https://anuchit1tube168-cmd.github.io/Javis-/liff-complete/`

## ฟังก์ชัน

- LINE Login / LIFF profile
- บัตรสมาชิกและคะแนนสะสม
- กิจกรรมบริจาคโลหิต
- บันทึกความดีพร้อมอัปโหลดรูป/PDF
- เอกสารของฉัน
- ข่าวใหม่พร้อม Badge กระพริบและสถานะอ่านแล้ว
- สิทธิพิเศษและสิทธิ์วันเกิด
- ติดต่อเจ้าหน้าที่ LINE OA
- Responsive mobile-first
- Demo fallback เมื่อยังไม่ได้ตั้ง LIFF/Supabase

## ตั้งค่า

แก้ไฟล์ `app.js`

```js
const CONFIG = {
  LIFF_ID: 'ใส่ LIFF ID',
  SUPABASE_URL: 'ใส่ Project URL',
  SUPABASE_ANON_KEY: 'ใส่ anon public key',
  LINE_OA_URL: 'https://line.me/R/oaMessage/@YOUR_OA_ID/'
};
```

ห้ามใส่ LINE Channel Access Token หรือ Supabase service role key ในไฟล์หน้าเว็บ

## LINE Developers

- LIFF Size: Full
- Endpoint URL: `https://anuchit1tube168-cmd.github.io/Javis-/liff-complete/`
- Scopes: `openid`, `profile`
- ตั้ง Rich Menu ให้เปิด LIFF URL: `https://liff.line.me/<LIFF_ID>`

## Production checklist

- ตรวจ LINE ID Token ฝั่ง Backend
- ผูก LINE User ID กับรหัสพนักงาน
- เปิด Row Level Security
- จำกัดชนิดและขนาดไฟล์
- เก็บไฟล์ใน Supabase Storage/R2
- เพิ่ม Audit Log
- เพิ่ม Admin News/Campaign Manager
- เพิ่ม Privacy Notice และ Consent
