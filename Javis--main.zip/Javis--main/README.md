# AGIS FieldOps ERP

เว็บแอปต้นแบบสำหรับบริหารงานบริการภาคสนามและทีมช่าง ออกแบบให้ใช้งานได้ทั้งคอมพิวเตอร์และมือถือ

## ฟีเจอร์ปัจจุบัน

- Dashboard ภาพรวมงานแบบเรียลไทม์
- งานบริการและตัวกรองสถานะ
- Dispatch Board แบบ Kanban
- ฐานข้อมูลลูกค้า
- Approval Queue ใบเสนอราคา
- คลังอะไหล่
- Fleet Management
- Management Analytics
- เปิดงานใหม่และบันทึกข้อมูลใน Local Storage
- Dark/Light Theme
- Responsive Mobile UI

## เปิดใช้งาน

เว็บไซต์จะถูก Deploy ผ่าน GitHub Actions ไปยัง GitHub Pages เมื่อมีการ Push เข้า branch `main`

URL เป้าหมาย:

`https://anuchit1tube168-cmd.github.io/Javis-/`

## โครงสร้างไฟล์

- `index.html` หน้าเว็บหลัก
- `styles.css` ระบบออกแบบและ Responsive UI
- `app.js` ข้อมูลจำลองและการทำงานของเว็บ
- `.github/workflows/pages.yml` ระบบ Deploy อัตโนมัติ

## ระยะถัดไป

เชื่อม Supabase/PostgreSQL, Login และ Role Permission, อัปโหลดรูปหน้างาน, ลายเซ็นลูกค้า, PDF Service Report, Notification และ Audit Log
