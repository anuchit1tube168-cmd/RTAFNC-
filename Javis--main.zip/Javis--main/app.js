const defaultJobs=[
{id:'JOB-24061',customer:'Siam Medical Co., Ltd.',type:'ตรวจสอบระบบไฟฟ้า',tech:'ธนกฤต',status:'active',due:'วันนี้ 14:30'},
{id:'JOB-24062',customer:'Metro Retail Group',type:'ซ่อมบำรุงตู้ MDB',tech:'วรพล',status:'pending',due:'วันนี้ 16:00'},
{id:'JOB-24063',customer:'Green Park Hotel',type:'ติดตั้งอุปกรณ์',tech:'ปกรณ์',status:'done',due:'เสร็จ 11:20'},
{id:'JOB-24064',customer:'Nova Logistics',type:'งานฉุกเฉิน',tech:'ณัฐพงศ์',status:'late',due:'เกิน 1 ชม.'},
{id:'JOB-24065',customer:'Central Lab',type:'PM ระบบไฟฟ้า',tech:'กิตติภพ',status:'active',due:'พรุ่งนี้ 09:00'},
{id:'JOB-24066',customer:'Bluewave Factory',type:'ตรวจโหลดไฟ',tech:'อนันต์',status:'done',due:'เสร็จ 10:15'}];
let jobs=JSON.parse(localStorage.getItem('agis_jobs')||'null')||defaultJobs;
const titles={dashboard:'ภาพรวมการปฏิบัติงาน',jobs:'งานบริการทั้งหมด',dispatch:'Dispatch & Assignment',customers:'ฐานข้อมูลลูกค้า',quotes:'ใบเสนอราคาและการอนุมัติ',inventory:'คลังอะไหล่',fleet:'ยานพาหนะและทีมภาคสนาม',analytics:'Management Analytics'};
const statusText={pending:'รอมอบหมาย',active:'กำลังดำเนินการ',done:'เสร็จแล้ว',late:'เกินกำหนด'};
const techs=[['ธนกฤต','กำลังทำงาน 2 งาน',78],['วรพล','พร้อมรับงาน',22],['ปกรณ์','กำลังเดินทาง',56],['ณัฐพงศ์','งานฉุกเฉิน',92],['กิตติภพ','พร้อมรับงาน',15]];
const customers=[['Siam Medical Co., Ltd.','โรงพยาบาลและเวชภัณฑ์','18 งาน','฿248K'],['Metro Retail Group','ค้าปลีก 12 สาขา','26 งาน','฿416K'],['Green Park Hotel','โรงแรมและรีสอร์ต','11 งาน','฿179K'],['Nova Logistics','คลังสินค้าและขนส่ง','9 งาน','฿203K'],['Central Lab','ห้องปฏิบัติการ','14 งาน','฿227K'],['Bluewave Factory','โรงงานอุตสาหกรรม','31 งาน','฿592K']];
const quotes=[['QT-260019','Metro Retail Group','฿186,400','24.5%'],['QT-260020','Nova Logistics','฿92,800','19.2%'],['QT-260021','Central Lab','฿241,000','28.8%']];
const stocks=[['สายไฟ CV 4x16','128 ม.','72%'],['เบรกเกอร์ MCCB 100A','18 ชิ้น','45%'],['Contactor 32A','7 ชิ้น','20%'],['หลอด LED High Bay','42 ชิ้น','66%'],['ฟิวส์ NH00','14 ชิ้น','38%'],['ตู้ Consumer Unit','6 ชิ้น','30%'],['Cable Lug 35mm','96 ชิ้น','82%'],['Relay 220V','11 ชิ้น','52%']];
const fleets=[['กข 4521','รถตู้ทีมช่าง A','กำลังออกงาน','78,220 กม.'],['บย 8874','รถกระบะทีมช่าง B','พร้อมใช้งาน','61,840 กม.'],['ฮษ 1209','รถ Mobile Service','เข้าศูนย์','103,450 กม.']];

function save(){localStorage.setItem('agis_jobs',JSON.stringify(jobs));}
function badge(s){return `<span class="badge ${s}">${statusText[s]}</span>`}
function render(){
 document.querySelector('#dashboardJobs').innerHTML=jobs.slice(0,5).map(j=>`<div class="job-row"><span class="job-id">${j.id}</span><div class="job-main"><strong>${j.customer}</strong><span>${j.type} · ${j.tech||'ยังไม่มอบหมาย'}</span></div>${badge(j.status)}<span class="due">${j.due}</span></div>`).join('');
 document.querySelector('#techList').innerHTML=techs.map((t,i)=>`<div class="tech"><div class="tech-avatar">${t[0].slice(0,1)}</div><div class="tech-info"><strong>${t[0]}</strong><small>${t[1]}</small></div><div class="load"><i style="width:${t[2]}%"></i></div></div>`).join('');
 renderJobs();renderKanban();
 document.querySelector('#customerCards').innerHTML=customers.map(c=>`<article class="entity-card"><span class="pill">CUSTOMER</span><h3>${c[0]}</h3><p>${c[1]}</p><div class="entity-meta"><span>${c[2]}</span><strong>${c[3]}</strong></div></article>`).join('');
 document.querySelector('#quoteList').innerHTML=quotes.map(q=>`<div class="quote-row"><strong>${q[0]}</strong><span>${q[1]}</span><strong>${q[2]}</strong><span>Margin ${q[3]}</span><div class="quote-actions"><button class="approve">อนุมัติ</button><button class="reject">ตีกลับ</button></div></div>`).join('');
 document.querySelector('#inventoryGrid').innerHTML=stocks.map(s=>`<div class="stock"><strong>${s[0]}</strong><b>${s[1]}</b><span>ระดับคงเหลือ ${s[2]}</span><div class="progress"><i style="width:${s[2]}"></i></div></div>`).join('');
 document.querySelector('#fleetCards').innerHTML=fleets.map(f=>`<article class="entity-card"><span class="pill">FLEET</span><h3>${f[0]}</h3><p>${f[1]}</p><div class="entity-meta"><span>${f[2]}</span><strong>${f[3]}</strong></div></article>`).join('');
 document.querySelector('#chart').innerHTML=[64,85,48,92,72,88,76].map((v,i)=>`<div class="chart-bar" style="height:${v}%"><span>${['จ','อ','พ','พฤ','ศ','ส','อา'][i]}</span></div>`).join('');
}
function renderJobs(){
 const q=(document.querySelector('#jobSearch')?.value||'').toLowerCase();const f=document.querySelector('#statusFilter')?.value||'all';
 document.querySelector('#jobsTable').innerHTML=jobs.filter(j=>(f==='all'||j.status===f)&&Object.values(j).join(' ').toLowerCase().includes(q)).map(j=>`<tr><td><strong>${j.id}</strong></td><td>${j.customer}</td><td>${j.type}</td><td>${j.tech||'-'}</td><td>${badge(j.status)}</td><td>${j.due}</td><td><button class="ghost-btn" onclick="advanceJob('${j.id}')">อัปเดต</button></td></tr>`).join('');
}
function renderKanban(){
 const cols=[['pending','รอมอบหมาย'],['active','กำลังดำเนินการ'],['late','ต้องเร่งติดตาม'],['done','เสร็จแล้ว']];
 document.querySelector('#kanban').innerHTML=cols.map(([s,t])=>`<div class="kanban-col"><div class="kanban-title"><span>${t}</span><span class="badge ${s}">${jobs.filter(j=>j.status===s).length}</span></div>${jobs.filter(j=>j.status===s).map(j=>`<div class="kanban-card"><span class="job-id">${j.id}</span><strong>${j.customer}</strong><span>${j.type}</span><span>ช่าง: ${j.tech||'ยังไม่มอบหมาย'} · ${j.due}</span></div>`).join('')}</div>`).join('');
}
window.advanceJob=id=>{const j=jobs.find(x=>x.id===id);if(!j)return;const order={pending:'active',active:'done',late:'active',done:'done'};j.status=order[j.status];save();render();toast('อัปเดตสถานะงานเรียบร้อย');};
function toast(msg){const el=document.querySelector('#toast');el.textContent=msg;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2200)}
function openModal(){document.querySelector('#jobModal').classList.add('show')}
function closeModal(){document.querySelector('#jobModal').classList.remove('show')}

document.querySelectorAll('.nav-item').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('.nav-item,.view').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.querySelector('#'+b.dataset.view).classList.add('active');document.querySelector('#pageTitle').textContent=titles[b.dataset.view];document.querySelector('#sidebar').classList.remove('open')}));
document.querySelectorAll('[data-jump]').forEach(b=>b.addEventListener('click',()=>document.querySelector(`[data-view="${b.dataset.jump}"]`).click()));
document.querySelector('#menuBtn').onclick=()=>document.querySelector('#sidebar').classList.toggle('open');
document.querySelector('#themeBtn').onclick=()=>document.body.classList.toggle('light');
document.querySelector('#newJobBtn').onclick=openModal;document.querySelector('#closeModal').onclick=closeModal;document.querySelector('#cancelModal').onclick=closeModal;
document.querySelector('#jobModal').addEventListener('click',e=>{if(e.target.id==='jobModal')closeModal()});
document.querySelector('#jobSearch').addEventListener('input',renderJobs);document.querySelector('#statusFilter').addEventListener('change',renderJobs);
document.querySelector('#jobForm').addEventListener('submit',e=>{e.preventDefault();const f=new FormData(e.target);const n=String(Math.max(...jobs.map(j=>+j.id.split('-')[1]))+1);jobs.unshift({id:'JOB-'+n,customer:f.get('customer'),type:f.get('type'),tech:f.get('tech')||'',status:f.get('tech')?'active':'pending',due:f.get('due')});save();render();e.target.reset();closeModal();toast('เปิดงานใหม่สำเร็จ');});
document.addEventListener('click',e=>{if(e.target.matches('.approve,.reject')){e.target.closest('.quote-row').style.opacity='.35';toast(e.target.matches('.approve')?'อนุมัติใบเสนอราคาแล้ว':'ส่งกลับเพื่อแก้ไขแล้ว')}});
render();
