const LIFF_ID='YOUR_LIFF_ID';
const jobs=[
 {id:'JOB-260018',title:'ตรวจสอบตู้ MDB อาคาร A',site:'บริษัท Siam Medical',status:'active',due:'วันนี้ 16:00'},
 {id:'JOB-260019',title:'ติดตั้งอุปกรณ์ไฟฟ้า',site:'Metro Retail สาขา 4',status:'pending',due:'พรุ่งนี้ 09:30'},
 {id:'JOB-260016',title:'ซ่อมระบบไฟฉุกเฉิน',site:'Green Park Hotel',status:'done',due:'เสร็จแล้ว'}
];
const labels={active:'กำลังดำเนินการ',pending:'รอรับงาน',done:'เสร็จแล้ว'};
let lineProfile={displayName:'ผู้ใช้งาน LINE',pictureUrl:'',userId:'DEMO'};
const $=s=>document.querySelector(s);
function renderJobs(){
 $('#jobList').innerHTML=jobs.map(j=>`<article class="job-card"><div class="job-top"><span class="job-id">${j.id}</span><span class="badge ${j.status}">${labels[j.status]}</span></div><h4>${j.title}</h4><p>${j.site}</p><div class="job-bottom"><span>กำหนด: ${j.due}</span><button onclick="openJob('${j.id}')" style="border:0;background:transparent;color:#0b7a41;font-weight:700">เปิดดู ›</button></div></article>`).join('');
}
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}
function sheet(title,eyebrow,body){$('#sheetTitle').textContent=title;$('#sheetEyebrow').textContent=eyebrow;$('#sheetBody').innerHTML=body;$('#sheet').classList.add('show')}
function closeSheet(){$('#sheet').classList.remove('show')}
window.openJob=id=>{const j=jobs.find(x=>x.id===id);sheet(j.id,'JOB DETAIL',`<div class="action-list"><div class="action-row"><span>สถานะ</span><strong>${labels[j.status]}</strong></div><div class="action-row"><span>สถานที่</span><strong>${j.site}</strong></div><div class="action-row"><span>กำหนด</span><strong>${j.due}</strong></div></div><button class="submit" style="width:100%;margin-top:14px" onclick="toast('อัปเดตสถานะแล้ว')">อัปเดตสถานะงาน</button>`)};
function showView(view){
 document.querySelectorAll('.bottom-nav button').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
 if(view==='home') return closeSheet();
 if(view==='myjobs') return sheet('งานของฉัน','MY SERVICE JOBS',jobs.map(j=>`<div class="action-row"><span>${j.id}<br><small>${j.title}</small></span><strong>${labels[j.status]}</strong></div>`).join(''));
 if(view==='newjob') return sheet('เปิดงานใหม่','NEW SERVICE REQUEST',`<form class="form" id="newJobForm"><label>ประเภทงาน<select><option>ตรวจสอบระบบไฟฟ้า</option><option>ซ่อมบำรุง</option><option>ติดตั้งอุปกรณ์</option><option>งานฉุกเฉิน</option></select></label><label>สถานที่<input required placeholder="ระบุสถานที่" /></label><label>รายละเอียด<textarea rows="4" placeholder="อธิบายปัญหาหรือความต้องการ"></textarea></label><button class="submit">ส่งคำขอ</button></form>`);
 if(view==='upload') return sheet('ส่งรูปและเอกสาร','UPLOAD EVIDENCE',`<form class="form" id="uploadForm"><label>เลือกใบงาน<select>${jobs.map(j=>`<option>${j.id} — ${j.title}</option>`).join('')}</select></label><label>ไฟล์รูปหรือ PDF<input type="file" accept="image/*,.pdf" multiple /></label><label>หมายเหตุ<textarea rows="3"></textarea></label><button class="submit">อัปโหลดไฟล์</button></form>`);
 if(view==='status') return sheet('ติดตามสถานะ','STATUS TRACKING',`<div class="action-list"><div class="action-row"><span>งานทั้งหมด</span><strong>5</strong></div><div class="action-row"><span>กำลังดำเนินการ</span><strong>2</strong></div><div class="action-row"><span>รออนุมัติ</span><strong>1</strong></div><div class="action-row"><span>เสร็จแล้ว</span><strong>2</strong></div></div>`);
 if(view==='profile') return showProfile();
}
function showProfile(){sheet('บัญชีผู้ใช้งาน','LINE MEMBER',`<div class="profile-box">${lineProfile.pictureUrl?`<img class="profile-photo" src="${lineProfile.pictureUrl}">`:`<div class="profile-photo"></div>`}<h3>${lineProfile.displayName}</h3><p>LINE User ID: ${lineProfile.userId.slice(0,12)}...</p></div><div class="action-list"><div class="action-row"><span>สถานะสมาชิก</span><strong>ยืนยันแล้ว</strong></div><div class="action-row"><span>บทบาท</span><strong>Technician</strong></div></div>`)}
async function initLiff(){
 try{
   if(LIFF_ID==='YOUR_LIFF_ID') throw new Error('demo');
   await liff.init({liffId:LIFF_ID});
   if(!liff.isLoggedIn()){liff.login();return;}
   lineProfile=await liff.getProfile();
   $('#displayName').textContent=lineProfile.displayName;
   $('#memberStatus').textContent='เชื่อมต่อบัญชี LINE แล้ว';
   $('#profileBtn').innerHTML=lineProfile.pictureUrl?`<img src="${lineProfile.pictureUrl}" alt="profile">`:lineProfile.displayName.slice(0,1);
 }catch(e){
   $('#displayName').textContent='โหมดสาธิต LIFF';
   $('#memberStatus').textContent='ใส่ LIFF ID เพื่อเปิด LINE Login จริง';
   $('#profileBtn').textContent='A';
 }
}
document.addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(b)showView(b.dataset.view)});
$('#profileBtn').onclick=showProfile;$('#closeSheet').onclick=closeSheet;$('#sheet').onclick=e=>{if(e.target.id==='sheet')closeSheet()};
document.addEventListener('submit',e=>{e.preventDefault();closeSheet();toast(e.target.id==='uploadForm'?'อัปโหลดไฟล์เรียบร้อย':'ส่งคำขอเรียบร้อย')});
renderJobs();initLiff();
